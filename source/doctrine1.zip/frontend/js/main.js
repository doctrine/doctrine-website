"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkdoctrine_website"] = self["webpackChunkdoctrine_website"] || []).push([["main"],{

/***/ "./source/js/main.js":
/*!***************************!*\
  !*** ./source/js/main.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* provided dependency */ var $ = __webpack_require__(/*! jquery */ \"./node_modules/jquery/dist/jquery.js\");\n/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__() {\n  function scrollFunction() {\n    if (\n      document.body.scrollTop > 20 ||\n      document.documentElement.scrollTop > 20\n    ) {\n      document.getElementById('back-to-top').style.display = 'block';\n    } else {\n      document.getElementById('back-to-top').style.display = 'none';\n    }\n  }\n\n  window.onscroll = function () {\n    scrollFunction();\n  };\n\n  $('#back-to-top').on('click', function () {\n    document.body.scrollTop = 0;\n    document.documentElement.scrollTop = 0;\n  });\n\n  $(document).ready(function () {\n    $('button[role=\"tab\"]').on('click', function () {\n        const tabId = $(this).attr('aria-controls');\n        const tabContent = $('#' + tabId);\n\n        $(this).closest('[role=tablist]').find('button[role=\"tab\"]')\n            .attr('data-active', null)\n            .attr('aria-selected', 'false');\n\n        $(this).attr('data-active', 'true').attr('aria-selected', 'true');\n\n        $(this).closest('[role=tablist]').parent().find('div[role=\"tabpanel\"]').hide();\n        tabContent.show();\n    });\n\n    $('button.copy-to-clipboard').on('click', async function () {\n      const copyElementId = $(this).data('copyElementId');\n      const copyElement = document.getElementById(copyElementId);\n\n      // Collect text from each child, separated by newlines\n      let copyText = '';\n      if (copyElement) {\n        const children = Array.from(copyElement.childNodes);\n        copyText = children.map(node => {\n          if (node.nodeType === Node.TEXT_NODE) {\n            return node.textContent;\n          } else if (node.nodeType === Node.ELEMENT_NODE) {\n            return node.textContent;\n          }\n          return '';\n        }).filter(Boolean).join('\\n');\n      }\n\n      await navigator.clipboard.writeText(copyText);\n    });\n\n    if (window.ga && window.ga.create) {\n      $('a').on('click', function () {\n        var eventCategory = $(this).data('ga-category');\n        var eventAction = $(this).data('ga-action');\n        var eventLabel = $(this).data('ga-label');\n        var eventValue = $(this).data('ga-value');\n        var fieldsObject = $(this).data('ga-fields-object');\n\n        if (eventCategory && eventAction) {\n          ga(\n            'send',\n            'event',\n            eventCategory,\n            eventAction,\n            eventLabel,\n            eventValue,\n            fieldsObject,\n          );\n        }\n      });\n    }\n  });\n}\n\n\n//# sourceURL=webpack://doctrine-website/./source/js/main.js?");

/***/ })

}]);